This Micro Game is created by Yash Jungade using Unity Game Developement Engine.

About Game:
Avoid Obstacles to Win!

About Controls:
Press "w" to move left.
Press "d" to move right.

Game will keep on restarting until you press start button on your keyboard and close game window to quit.

Thank You for Downloading.
Hope You Enjoy This Micro & Fun Game 